const $ = document;
const videoSrc = $.querySelectorAll('.video-Src');
const Video = $.querySelector(".video");
const playBtn = $.querySelector(".btn-play");
const btnSpeed = $.querySelector(".btn-speed");
const btnSpeedLess = $.querySelector(".btn-speedLess");
const btnPrev = $.querySelector(".btn-prev");
const btnNext = $.querySelector(".btn-next");
const videoBox  = $.querySelector(".video-box")
window.addEventListener("resize", function () {
  if (this.window.innerWidth < 700) {
                        let data = playBtn.getAttribute("data-icon");
                        if (data == "play") {
                          Video.play();
                          playBtn.removeAttribute("src");
                          playBtn.setAttribute("src", "./icons/pause.png");
                          playBtn.setAttribute("data-icon", "pause");
                          data = playBtn.getAttribute("data-icon");
                        } else if (data == "pause") {
                          Video.pause();
                          playBtn.removeAttribute("src");
                          playBtn.setAttribute("src", "./icons/play.png");
                          playBtn.setAttribute("data-icon", "play");
                          data = playBtn.getAttribute("data-icon");
                        }
  }
});
function playHandler() {
  let data = playBtn.getAttribute("data-icon");
  if (data == "play") {
    Video.play();
    playBtn.removeAttribute("src");
    playBtn.setAttribute("src", "./icons/pause.png");
    playBtn.setAttribute("data-icon", "pause");
    data = playBtn.getAttribute("data-icon");
  } else if (data == "pause") {
    Video.pause();
    playBtn.removeAttribute("src");
    playBtn.setAttribute("src", "./icons/play.png");
    playBtn.setAttribute("data-icon", "play");
    data = playBtn.getAttribute("data-icon");
  }
}
function speedFastHandler() {
  Video.playbackRate = 2;
}
function btnSpeedLessHandler() {
  Video.playbackRate = 1;
}
btnSpeed.addEventListener("click", speedFastHandler);
btnSpeedLess.addEventListener("click", btnSpeedLessHandler);
playBtn.addEventListener("click", playHandler);


